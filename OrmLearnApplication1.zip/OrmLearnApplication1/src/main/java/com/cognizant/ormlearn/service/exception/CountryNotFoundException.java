package com.cognizant.ormlearn.service.exception;

public class CountryNotFoundException extends Exception{

}