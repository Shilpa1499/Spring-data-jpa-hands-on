package com.cognizant.repository;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.stock.Stock;
@Repository
public interface StockRepository extends CrudRepository<Stock, Integer>{
	public List<Stock> findAllByDateBetween(Date startDate, Date endDate);
	public List<Stock> findAllByStockopenGreaterThan(BigDecimal price);
	public List<Stock> findTop3OrderByStockvolumeDesc();
	public List<Stock> findTop3StockcodeOrderByStockcloseAsc(String stockcode);
	
}