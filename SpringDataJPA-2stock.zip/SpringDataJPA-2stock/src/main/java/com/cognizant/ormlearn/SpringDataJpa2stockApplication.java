package com.cognizant.ormlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.repository.StockRepository;
import com.cognizant.stock.Stock;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;




@SpringBootApplication
public class SpringDataJpa2stockApplication {
	

	public static void main(String[] args) throws ParseException  {
		ApplicationContext context = SpringApplication.run(SpringDataJpa2stockApplication.class, args);
		StockRepository stockRepository = context.getBean(StockRepository.class);
		
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate =formatter.parse("2019-09-01");
		Date endDate =formatter.parse("2019-09-30");
		List<Stock> stock_date_for_sept = stockRepository.findAllByDateBetween(startDate , endDate);
		System.out.println(stock_date_for_sept);
		
		List<Stock> stockprice = stockRepository.findAllByStockopenGreaterThan(new BigDecimal(1250));
		System.out.println(stockprice);
	
		List<Stock> highesttop_volume_dates = stockRepository.findTop3OrderByStockvolumeDesc();
		System.out.println(highesttop_volume_dates);
		
		String code="NFLX";
		List<Stock> lowest_stock_volume_netflix = stockRepository.findTop3StockcodeOrderByStockcloseAsc(code);
		System.out.println(lowest_stock_volume_netflix);
	}


}