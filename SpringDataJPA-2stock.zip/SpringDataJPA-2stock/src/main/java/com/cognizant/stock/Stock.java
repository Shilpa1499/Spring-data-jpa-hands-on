package com.cognizant.stock;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;

import org.springframework.boot.autoconfigure.domain.EntityScan;

@Entity
@Table(name="stock")
public class Stock {
@Id
@Column(name="st_id")
private int stock_id;
@Column(name="st_code")
private String stockcode;
@Column(name="st_date")
private Date date;
@Column(name="st_open")
private BigDecimal 	stockopen;
@Column(name="st_close")
private BigDecimal stockclose;
@Column(name="st_volume")
private BigDecimal stockvolume;
public Stock() {
	super();
	// TODO Auto-generated constructor stub
}
public Stock(int stock_id, String stockcode, Date date, BigDecimal stockopen, BigDecimal stockclose,
		BigDecimal stockvolume) {
	super();
	this.stock_id = stock_id;
	this.stockcode = stockcode;
	this.date = date;
	this.stockopen = stockopen;
	this.stockclose = stockclose;
	this.stockvolume = stockvolume;
}
public int getStock_id() {
	return stock_id;
}
public void setStock_id(int stock_id) {
	this.stock_id = stock_id;
}
public String getStockcode() {
	return stockcode;
}
public void setStockcode(String stockcode) {
	this.stockcode = stockcode;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public BigDecimal getStockopen() {
	return stockopen;
}
public void setStockopen(BigDecimal stockopen) {
	this.stockopen = stockopen;
}
public BigDecimal getStockclose() {
	return stockclose;
}
public void setStockclose(BigDecimal stockclose) {
	this.stockclose = stockclose;
}
public BigDecimal getStockvolume() {
	return stockvolume;
}
public void setStockvolume(BigDecimal stockvolume) {
	this.stockvolume = stockvolume;
}
@Override
public String toString() {
	return "Stock [stock_id=" + stock_id + ", stockcode=" + stockcode + ", date=" + date + ", stockopen=" + stockopen
			+ ", stockclose=" + stockclose + ", stockvolume=" + stockvolume + "]";
}

	
}