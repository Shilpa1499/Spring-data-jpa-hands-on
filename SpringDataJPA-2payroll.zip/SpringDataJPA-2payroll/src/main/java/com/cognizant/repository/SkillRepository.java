package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Skill;

@Repository
public interface SkillRepository extends CrudRepository<Skill, Integer>{
	Skill findById(int id);

}