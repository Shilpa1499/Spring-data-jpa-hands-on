package com.cognizant.ormlearn.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;
import com.cognizant.ormlearn.service.CountryService;

@Controller
public class CountryController {
	@Autowired
	private CountryRepository countryRepository;
	@RequestMapping(value="/countries",method=RequestMethod.GET)
	public String enterCountry()
	{
		return "countries";
	}
	
	@RequestMapping(value="/displaycountry",method=RequestMethod.GET)
	public String checkCountry(ModelMap map,  @ModelAttribute("country") Country country,@Param("name") String name)
	{
		
		List<Country> country1=countryRepository.findByNameContainingOrderByNameAsc(name);
		map.addAttribute("country1",country1);
		return "displaycountry";
	      
	}
	@RequestMapping(value="/displaysearch",method=RequestMethod.GET)
	public String checkCountryStartingWith(ModelMap map,  @ModelAttribute("country") Country country,@Param("n") String name)
	{
		List<Country> country2=countryRepository.findByNameStartingWith(name);
		map.addAttribute("country2",country2);
		return "displaysearch";
	      
	}
}